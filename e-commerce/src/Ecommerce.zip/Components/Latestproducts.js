import React from "react";
import products from "./Productdata"
import { useNavigate } from "react-router-dom";

import "./Latestproducts.css";

function Latestproducts() {
    const navigate = useNavigate();
    const handleProductClick = (id) => {
        navigate(`/product/${id}`);
    };
    return (
        <div className="latestprod">
            <div className="latesttop">
                <h1>Our Latest Products</h1>
                <button>First to Shop Now</button>
            </div>
            <div className="product-cards-container">
                {products.map((product) => (
                    <div
                        key={product.id}
                        className="product-card-item"
                        onClick={() => handleProductClick(product.id)}
                    >
                        <img src={product.image} alt={product.name} className="productimage" />
                        <h3>{product.name}</h3>
                        <p>{product.price}</p>
                    </div>
                ))}
            </div>
        </div>
    )
}
export default Latestproducts;