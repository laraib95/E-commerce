import Cartiadges from '../Images/Cartiadges.jpg';
import EthernetPort from '../Images/EthernetPort.jpg';
import HighYeildCartiadges from '../Images/High-yeildCartiadges.jpg';
import IPadPen from '../Images/IPadPen.jpg';
import MemoryCard from '../Images/Memory.jpg';
import SamsungTabs from '../Images/TabsCase.jpg';
import ScreenProtector from '../Images/Protector.jpg'
import Seagate from '../Images/SeagateHHD.jpg';
import WirelessMouse from '../Images/WirelessMouse.jpg';


const products = [
    {
        id: 0,
        image: Cartiadges,
        name: "Logitech M185 Wireless Mouse, 2.4GHz with USB Mini Receiver, 12-Month Battery Life, 1000 DPI Optical Tracking, Ambidextrous PC/Mac/Laptop - Swift Grey",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$14",
    },
    {
        id: 1,
        image: EthernetPort,
        name: "TP-Link AC1200 WiFi Extender, 2025 Wirecutter Best WiFi Extender, 1.2Gbps home signal booster, Dual Band 5GHz/2.4GHz, Up to 1600 Sq.ft and 32 Devices, EasyMesh Compatible, One Ethernet Port (RE315)",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$22",
    },
    {
        id: 2,
        image: HighYeildCartiadges,
        name: "HP 63XL Black High-yield Ink Cartridge | Works with HP DeskJet 1112, 2130, 3630 Series; HP ENVY 4510, 4520 Series; HP OfficeJet 3830, 4650, 5200 Series | Eligible for Instant Ink | F6U64AN",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$57",
    },
    {
        id: 3,
        image: IPadPen,
        name: "Stylus Pen for iPad 6th-11th Generation-2X Fast Charge Active Pencil Compatible with 2018-2025 Apple iPad Pro 11/12.9/M4, iPad Air 3/4/5/M2/M3,iPad mini 5/6 Gen-White",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$18",
    },
    {
        id: 4,
        image: MemoryCard,
        name: "Amazon Basics Micro SDXC Memory Card with Full Size Adapter, A2, U3, Read Speed up to 100 MB/s, 128 GB, Black",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$11",
    },
    {
        id: 5,
        image: SamsungTabs,
        name: "Ailun Screen Protector for iPad 11th A16 2025 [11 Inch] / 10th Generation 2022 [10.9 Inch], Tempered Glass [Face ID & Apple Pencil Compatible] Ultra Sensitive Case Friendly [2 Pack]",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$6",
    },
    {
        id: 6,
        image: ScreenProtector,
        name: "Samsung Galaxy Tab A9+ Tablet 11” 64GB Android Tablet, Big Screen, Quad Speakers, Upgraded Chipset, Multi Window Display, Slim, Light, Durable Design, US Version, 2024, Graphite",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$57",
    },
    {
        id: 7,
        image: Seagate,
        name: "Seagate Portable 2TB External Hard Drive HDD — USB 3.0 for PC, Mac, PlayStation, & Xbox -1-Year Rescue Service (STGX2000400)",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$69",
    },
    {
        id: 8,
        image: WirelessMouse,
        name: "Logitech M185 Wireless Mouse, 2.4GHz with USB Mini Receiver, 12-Month Battery Life, 1000 DPI Optical Tracking, Ambidextrous PC/Mac/Laptop - Swift Grey",
        description: `Original HP Ink Cartridges are engineered to work with HP printers to provide consistent quality, reliability and value
This cartridge works with- HP DeskJet 1255, 2710e, 2720e, 2721e, 2722, 2722e, 2723e, 2724, 2725, 2732 2742e 2752e 2755 2755e 4110e 4120e 4121e 4122e 4123e 4130e, 4132e, 4152e, 4155e, 4158e HP DeskJet Plus 4122, 4132, 4155
This cartridge works with-  HP ENVY 6010e, 6020e, 6022e, 6030e, 6032e, 6034e, 6050e, 6052e, 6055, 6055e, 6075, 6075e, 6420e, 6422e, 6430e, 6432e, 6450e, 6452e, 6455e, 6458e, 6475e; HP ENVY Pro 6455, 6458, 6475
Cartridge yield (approx.)- 120 pages black, 100 pages tri-color
88% of HP ink cartridges are manufactured with recycled plasti`,
        price: "$14",
    },
]
export default products;
