import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import products from './Productdata'; 
import { useCart } from './Cartcontext';
import "./Productdetail.css";


const ProductDetail = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const {addToCart} = useCart();
  const product = products.find(p => p.id === parseInt(id, 10));

  if (!product) {
    return (
      <div style={{ padding: '20px', color:'red'}}>
        <h2>Product Not Found</h2>
        <button onClick={() => navigate(-1)}>Go Back</button>
      </div>
    );
  }

  const handleAddToCartClick = () => {
   addToCart(product);
   navigate('/Cartscreen');
  };

  return (
    <div className="main">
      <button onClick={() => navigate(-1)} >
        ← Back
      </button>

      <div className="container">
        <img
          src={product.image}
          alt={product.name}
        />
        <div className="text">
          <h1>{product.name}</h1>
          <p >{product.description}</p>
          <h2 >${typeof product.price === 'number' ? product.price.toFixed(2) : parseFloat(String(product.price).replace('$', '')).toFixed(2)}</h2>
          <button className="Addtocart" onClick={handleAddToCartClick} >Add to Cart</button>
        </div>
      </div>
    </div>
  );
};

export default ProductDetail;