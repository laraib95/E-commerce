import products from "./Productdata";
import { useNavigate } from "react-router-dom";
import './Productcard.css';

function Productcard() {
    const navigate = useNavigate();
    return (
        <div className="maingrid">
            {products.map((product) => (
                <div key={product.id} className="product_grid"
                    onClick={() => navigate(`/product/${product.id}`)}
                >
                    <img src={product.image} alt={product.name} className="productimage" />
                    <h3>{product.name}</h3>
                    <p>{product.price}</p>
                </div>
            ))}
        </div>
    );
}
export default Productcard;