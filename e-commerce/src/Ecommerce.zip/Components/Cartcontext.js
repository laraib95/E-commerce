import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();
export const useCart = () => {
  return useContext(CartContext);
};

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    try {
      const stored = localStorage.getItem("cart");
      if (stored) {
        const parsedCart = JSON.parse(stored);
        if (Array.isArray(parsedCart)) {
          return parsedCart.map(item => ({
            ...item,
            price: parseFloat(String(item.price).replace('$', '')) || 0,
            quantity: parseInt(item.quantity) || 1
          }));
        }
      }
    } catch (e) {
      console.error("Failed to parse cart from localStorage:", e);
    }
    return [];
  });
  useEffect(() => {
    localStorage.setItem("cart", JSON.stringify(cartItems));
    console.log("Cart items stored to localStorage:", cartItems);
  }, [cartItems]);

  const addToCart = (productToAdd) => {
    setCartItems(prevItems => {
      const existingItemIndex = prevItems.findIndex(item => item.id === productToAdd.id);

      if (existingItemIndex > -1) {
        return prevItems.map((item, index) =>
          index === existingItemIndex
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        const newItem = {
          id: productToAdd.id,
          image: productToAdd.image,
          name: productToAdd.name,
          description: productToAdd.description,
          price: parseFloat(String(productToAdd.price).replace('$', '')),
          quantity: 1
        };
        return [...prevItems, newItem];
      }
    });
  };

  const removeFromCart = (id) => {
    setCartItems(prevItems => prevItems.filter(item => item.id !== id));
  };

  const updateQuantity = (id, newQty) => {
    const quantity = Math.max(1, parseInt(newQty) || 1); 
    setCartItems(prevItems =>
      prevItems.map(item =>
        item.id === id ? { ...item, quantity: quantity } : item
      )
    );
  };
  const totalItemsInCart = cartItems.reduce((total, item) => total + item.quantity, 0);

  const contextValue = {
    cartItems,
    totalItemsInCart,
    addToCart,
    removeFromCart,
    updateQuantity,
  };

  return (
    <CartContext.Provider value={contextValue}>
      {children}
    </CartContext.Provider>
  );
};