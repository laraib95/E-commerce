import React from 'react';
import { Link } from 'react-router-dom'; 
import './Footer.css'; 

import FacebookIcon from "../Images/facebook-logo.png";
import TwitterIcon from "../Images/twitter-logo.png";
import InstagramIcon from "../Images/insta-logo.png";


function Footer() {
    const currentYear = new Date().getFullYear();
    // const navigate = useNavigate();

    return (
        <footer className="site-footer">
            <div className="footer-content">
                <div className="footer-section about">
                    <h3>GO Shopping</h3>
                    <p>Your one-stop shop for all your needs. We deliver quality products right to your doorstep with care and speed.</p>
                </div>

                <div className="footer-section links">
                    <h3>Quick Links</h3>
                    <ul>
                        <li><Link to="/">Home</Link></li>
                        <li><Link to="/Productcard">Products</Link></li> 
                        <li><Link to="/Cartscreen">Cart</Link></li>
                        <li><Link to="/about">About Us</Link></li>
                        <li><Link to="/contact">Contact Us</Link></li>
                        <li><Link to="/login">Login</Link></li>
                    </ul>
                </div>

                <div className="footer-section social">
                    <h3>Follow Us</h3>
                    <div className="social-links">
                        <a href="https://facebook.com" target="_blank" rel="noopener noreferrer">
                            <img src={FacebookIcon} alt='Facebook Link' className="fab fa-facebook-f"></img> 
                            <span>Facebook</span>
                        </a>
                        <a href="https://twitter.com" target="_blank" rel="noopener noreferrer">
                            <img src={TwitterIcon} alt='Twitter link' className="fab fa-twitter"></img> 
                            <span>Twitter</span>
                        </a>
                        <a href="https://instagram.com" target="_blank" rel="noopener noreferrer">
                            <img src={InstagramIcon} alt='Instagram link' className="fab fa-instagram"></img>
                            <span>Instagram</span>
                        </a>
                    </div>
                </div>

                <div className="footer-section contact">
                    <h3>Contact Info</h3>
                    <p><i className="fas fa-map-marker-alt"></i> 123 Shopping St, Retail City, State 12345</p>
                    <p><i className="fas fa-phone"></i> +1 234 567 8900</p>
                    <p><i className="fas fa-envelope"></i> info@goshopping.com</p>
                </div>
            </div>

            <div className="footer-bottom">
                &copy; {currentYear} GO Shopping. All rights reserved.
            </div>
        </footer>
    );
}

export default Footer;