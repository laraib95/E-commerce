import "./Navigation.css"
import Carticon from "../Images/carticon.png";
import { Link } from "react-router-dom";
import { useCart } from "./Cartcontext";
import logo from "../Images/logo.jpeg";
function Navigation() {
    const { totalItemsInCart } = useCart;
    console.log('Total items in cart in Navigation:', totalItemsInCart); // <-- ADD THIS LINE

    return (
        <div className="header">
            <div className="logoname">
                <img src={logo} alt="Website Logo" className="logo"></img>
                <h1>GO Shopping</h1>
            </div>
            <div className="Navigationbar">
                <ul>
                    <li><Link to="/" >Home</Link></li>
                    <li><Link to="/about">About</Link></li>
                    <li><Link to="Contactus">Contact us</Link></li>
                </ul>
            </div>
            <Link to="/login">
                <button className="loginbutton">Login</button>
            </Link>
            <Link to="/Cartscreen">
                <img src={Carticon} alt="Cart" className="carticon"></img>
            </Link>
        </div>
    );
}
export default Navigation;