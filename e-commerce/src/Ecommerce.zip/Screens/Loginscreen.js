    import React, { useState } from "react";
import FBlogo from '../Images/facebook-logo.png'
import googlelogo from '../Images/googleicon.png'
import './Loginscreen.css';
function LoginScreen() {
    const [email, setemail] = useState("");
    const [password, setpassword] = useState("");
    const [error, seterror] = useState("");
    const [loggedin, setloggedin] = useState(false);
            const validateEmail = (email) => {
            const re = /\S+@\S+\.\S+/;
            return re.test(email);
        }
    const handlesubmit = (event) => {
        event.preventDefault();
        if (!email || !password) {
            seterror("Both Fields are required!");
            return;
        }
        if (!validateEmail(email)) {
            seterror("Invalid Email Format!");
        }
        if (email === 'user123@gmail.com' && password === "password123") {
            setloggedin(true);
            seterror(" ");
        }
        else {
            seterror("Invald Email or Password!");
        }

    };
    return (
        <div className="Loginwrapper">
            <h1>Login to Shop please</h1>
            <div className="inputs">
                {loggedin ? (
                    <p>Logged In successfuly</p>
                ) :
                    (
                        <form onSubmit={handlesubmit}>
                            <div className="emailpassword">
                                <label>Email</label>
                                <input className="Email" type="email" placeholder="enter your email" value={email} 
                                onChange={(e)=>setemail(e.target.value)} required></input>
                                <label>Password</label>
                                <input type="password" placeholder="enter the password" value={password}
                                onChange={(e) => setpassword(e.target.value)} required></input>
                            </div>
                            {error && <p style={{color:"red"}}>{error}</p>}
                            <div className="formbuttons">
                                <button type="sign">Sign up</button>
                                <button type="submit">Login</button>
                            </div>
                            <div className="logos">
                                <img src={FBlogo} alt="Fb logo"></img>
                                <img src={googlelogo} alt="Googlelogo"></img>
                            </div>
                        </form>
                    )
                }
            </div>
        </div>
    );
}
export default LoginScreen;