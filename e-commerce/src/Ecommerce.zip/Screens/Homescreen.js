
import "./Homescreen.css"
import Latestproducts from "../Components/Latestproducts";
import salesimage from "../Images/sale-items.jpg";
import { useNavigate } from 'react-router-dom';

function Homescreen() {
    const navigate = useNavigate(); 

  const handleGrabSaleClick = () => {
    navigate('/Productcard');
  };
    return (
        <div className="home">
            <div className="salesection">
                <div className="sales-section-left">
                    <h1>Discount Offer! </h1>
                    <p>Don't miss out! Explore our latest deals and limited-time offers to find exactly what you need at unbeatable prices.Unlock incredible savings across our entire collection. These special sales are designed to bring you premium quality without the premium price tag.</p>
                    <button className="salebutton" onClick={handleGrabSaleClick} >Grab Sale Now</button>
                </div>
                <div className="sales-section-right">
                    <img src={salesimage} alt="sale Products" ></img>
                </div>
            </div>
            {/* <Productcard /> */}
            <hr style={{ border: "none", borderTop: "2px solid black", width: "900px" }} />
            < Latestproducts />
        </div>
    );
}
export default Homescreen;