import { useNavigate } from 'react-router-dom';
import { useCart } from '../Components/Cartcontext';
import "./Cartscreen.css";

const CartScreen = () => {
  const navigate = useNavigate();
  const { cartItems, removeFromCart, updateQuantity } = useCart();

  const totalCost = cartItems.reduce((sum, item) => {
    const price = parseFloat(item.price) || 0;
    const quantity = parseInt(item.quantity) || 0;
    return sum + (price * quantity);
  }, 0);
  if (cartItems.length === 0) {
    return (
      <div className="empty-cart">
        <h2>Your cart is empty</h2>
        <button onClick={() => navigate("/")}>Shop Now</button>
      </div>
    );
  }

  return (
    <div className="cart-container">
      <h2>Your Cart</h2>
      {cartItems.map(item => (
        <div className="cart-items" key={item.id}>
          <img src={item.image} alt={item.name} />
          <div className="cart-item">
            <h3 className="item-name">{item.name}</h3>
            <p className="item-price">${item.price.toFixed(2)}</p>
            <div className='quantitydiv'>
              <p>Qty</p>
              <input className="quantity-control"
                type="number"
                value={item.quantity}
                onChange={(e) => updateQuantity(item.id, e.target.value)}
                min="1"
              />
            </div>
          </div>
          <button className="remove-button" onClick={() => removeFromCart(item.id)} >
            Remove
          </button>
        </div>
      ))}
      <hr style={{ borderTop: '2px solid #ccc', margin: '20px 0' }} />
      <div className="cart-summary" style={{}}>
        <h3>Total: ${totalCost.toFixed(2)}</h3>
      </div>
    </div>
  );
};

export default CartScreen;