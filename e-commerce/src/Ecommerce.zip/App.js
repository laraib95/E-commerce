import { BrowserRouter, Route, Routes } from 'react-router-dom';
import Homescreen from './Screens/Homescreen';
// import ProductScreen from "./Screens/Productscreen";
import Products from './Components/Productcard';
import Cartscreen from "./Screens/Cartscreen";
import Navigation from './Components/Navigation';
import { CartProvider } from './Components/Cartcontext';
import LoginScreen from './Screens/Loginscreen';
import ProductDetail from './Components/Productdetail';
// import productcard from "./Components/Productcard"
import Footer from './Components/Footer';
function App() {
  return (
    <div>
      <BrowserRouter>
        <Navigation />
        <CartProvider>
          <Routes>
            <Route path="/product/:id" element={<ProductDetail />} />
            <Route path="/" element={<Homescreen />} />
            <Route path="/Productcard" element={<Products/>} />
            <Route path="/Login" element={<LoginScreen />} />
            <Route path="/Cartscreen" element={<Cartscreen />} />
          </Routes>
        </CartProvider>
        <Footer />
      </BrowserRouter>
    </div>
  );
}
export default App;
